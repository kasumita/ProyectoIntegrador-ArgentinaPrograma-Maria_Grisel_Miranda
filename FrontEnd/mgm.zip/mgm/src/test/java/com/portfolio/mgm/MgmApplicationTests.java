package com.portfolio.mgm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MgmApplicationTests {

	@Test
	void contextLoads() {
	}

}
